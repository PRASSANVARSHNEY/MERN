const userAllProduct= async(req,res)=>{
    res.status(501);
    res.json({
        status: 'fail',
        message:'Route is not yet implemented',
    });
}


const userAddproduct=async(req,res)=>{
    res.status(501);
    res.json({
        status: 'fail',
        message:'Route is not yet implemented',
    });
}

const replaceProduct=async(req,res)=>{
    res.status(501);
    res.json({
        status: 'fail',
        message:'Route is not yet implemented',
    });
}

const deleteProduct=async(req,res)=>{
    res.status(501);
    res.json({
        status: 'fail',
        message:'Route is not yet implemented',
    });
}

module.exports = {
    userAllProduct,
    userAddproduct,
    replaceProduct,
    deleteProduct
}
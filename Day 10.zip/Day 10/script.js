const express = require('express')
//const fs = require('fs')
const fsPromises = require('fs/promises')
const app = express();

const productController=require('./controller/productsController.js');
const userController=require('./controller/usersController.js');

app.use(express.json());
const productRouter=require('./routes/productrouters');
const userRouter=require('./routes/userrouters');
app.use((req,res,next)=>{
    // console.log(req.url)
    const time = new Date().toLocaleString();
    fsPromises.appendFile("./log.txt", req.url + '\t' + time +'\n');   

    next();
});
// app.get('/api/products',productController.getAllProducts);
//to get data and display on browser
// app.get('/api/recipes', async(req,res)=>{
//     //const data = fs.readFileSync('./data.json','utf8');
//     const data = await fsPromises.readFile('./data.json','utf8');
//     const arr = JSON.parse(data);
//     //res.json(obj);
//     // res.send("Welcome GET");
//     res.json(arr)
// }); 
 

// for posting data on browser . for adding new data

// app.post('/api/recipes',async (req,res)=>{
//     // console.log(Object.keys(req));
//     //console.log(req.body);
//     const data = req.body;
    
//     const db = await fsPromises.readFile("./data.json",'utf8');
//     const arr = JSON.parse(db);
//     const len = arr.length;
//     const newProduct = data;
//     if(len==0){
//         newProduct.id = 1;
//     }
//     else{
//         newProduct.id = (arr[len-1].id)+1;
//     }
//     arr.push(newProduct);
//     fsPromises.writeFile("./data.json", JSON.stringify(arr));
//     res.json({
//         status: 'success',
//         results: 1,
//         data:{
//             newProduct: newProduct,
//         }
//     })

// })

// put request. for replacing data
// app.put('/api/recipes/:id', async(req,res)=>{
//     //console.log(req);
//     const arr = JSON.parse(await fsPromises.readFile("./data.json","utf8"));
//     //res.send("work in progress...");
//     const reqId = parseInt(req.params.id);
//     const data = req.body;
//     const newArr= arr.map((elem)=>{
//         if(elem.id == reqId)return data;
//         else return elem;
//     })
//     fsPromises.writeFile("./data.json",JSON.stringify(newArr))
//     res.json({
//         status: 'success',
//         results: 1,
//         data:{
//             newProduct: data,
//         }
//     })
// })

// delete request
// app.delete('/api/recipes/:id', async(req,res)=>{
//     const reqId = parseInt(req.params.id);
//     const arr = JSON.parse(await fsPromises.readFile("./data.json","utf8"));
//     const newArr = arr.filter((elem)=>{
//         if(elem.id === reqId)return false;
//         else return true;
//     });
//     await fsPromises.writeFile("./data.json",JSON.stringify(newArr));
//     res.status(204);
//     res.json({
//         status: 'success',
//         data:{
//             newProduct: null,
//         }
//     })
// });

app.get('api/products',productController.getAllProduct);
app.post('api/products',productController.addProduct);
app.put('api/products',productController.replaceProduct);
app.delete('api/products',productController.getAllProduct);
app.get('api/users',userController.userAllProduct);
app.post('api/users',userController.userAddProduct);
app.put('api/users',userController.replaceProduct);
app.delete('api/users',userController.deleteProduct);

// app.get('/api/users',async(req,res)=>{
//     res.status(501);
//     res.json({
//         status: 'fail',
//         message:'Route is not yet implemented',
//     });
// })

// app.post('/api/users',async(req,res)=>{
//     res.status(501);
//     res.json({
//         status: 'fail',
//         message:'Route is not yet implemented',
//     });
// })

// app.put('/api/users',async(req,res)=>{
//     res.status(501);
//     res.json({
//         status: 'fail',
//         message:'Route is not yet implemented',
//     });
// })

// app.delete('/api/users',async(req,res)=>{
//     res.status(501);
//     res.json({
//         status: 'fail',
//         message:'Route is not yet implemented',
//     });
// })

app.use('/api/products',productRouter);
app.use('/api/users',userRouter);
app.listen(1500);
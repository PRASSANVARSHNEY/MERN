//latency
//round-trip-latency
//response time
//throughput 
//bandwidth
//http vs https
//IP address, MAC address
//Router, ISP, Internet
//DNS
//read evaluate process loop
// const name='pefne';
// function mul(a,b){
//     console.log(a*b);
// }
// function add(a,b){
//     console.log(a+b);
// }
// module.exports={
//     // fn1:add,
//     // fn2:mul,
//     add,
//     mul,
//     'name':name,
// };

// console.log("fdjfjsf");
// sum(30,8);


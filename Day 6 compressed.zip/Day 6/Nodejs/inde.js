// var figlet = require("figlet");

// figlet("dnjhnnf", (err, data) =>{
//     console.log(data);
// });

//   if (err) {
//     console.log("Something went wrong...");
//     console.dir(err);
//     return;

//   }
//   console.log(data);
// });

//old method
// fetch('https://api.github.com/users/deepak3440').then((res)=>{
//     return res.json();
// })
// .then((data)=>{
//     console.log(data);
// })

//async await fetch calling
// async function getApi(){
//     const pr=await fetch('https://api.github.com/users/deepak3440');
//     // console.log(pr);
//     const data = await pr.json();
//     console.log(data);
// }
// getApi();

console.log('start');

async function callAPI(){
    const pr = new Promise((res,rej)=>{
        console.log('promise started');
        setTimeout(()=>{
            console.log('timeout 1...')},10000);
        })
        console.log('promise 1 completed');
    }

    // const pr2 = new Promise((res,rej)=>{
    //     console.log('promise2');
    //     setTimeout(()=>{
    //         console.log('timeout 1...')},10000);
    //     })
    // }
  callAPI();
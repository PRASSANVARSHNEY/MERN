// const obj= require('./module');
// obj.add(2,3);
// obj.mul(2,3);
// console.log(obj.name);



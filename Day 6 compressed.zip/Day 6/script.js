// setTimeout(()=>{console.log('timeou')},30000)
// console.log('start');

// setTimeout(()=>{console.log('timeout')},60000)
// console.log('intermediate')
// console.log('end');

//create order()
// function createorder(x,fn){
//     console.log(x);
//     setTimeout( ()=>{fn('li123')},10000);
// }

// //create payment()
// function makepayment(orderid)
// {
//     console.log(orderid);
// }

// making promise
 
// const pr=new Promise((x,y)=>{
// if(true)
// {
//     x();
// }
// else{
//     y();
// }
// });

// console.log(pr);
// setTimeout(()=>{console.log('first timeout...')},0)
// const pr=new Promise((resolve,reject)=>{
//     setTimeout(()=>{reject("done123");},5000);
//     setTimeout(()=>{resolve("kya hai be");},5000);
// });
// // console.log(pr);
// pr.then((res)=>{
//     console.log(res);
// }).catch((err)=>{
//     console.log(err);
// })

// setTimeout(function abc(){
//     console.log('Isdbd');
// },0);

// const pr = new Promise((res,rej)=>{
//     setTimeout(()=>{res('done')},0);
// })

// pr.then(function b(res)
// {
// console.log('promise completed:',res);
// })

// setTimeout(function xyz(){
//     console.log('kdjhf');
// },0);

// console.log('hello');

// const arr=[10,22,34];
// const ans=arr.map((a)=>{
//     console.log(a);
//     return a*2;
// });

// console.log(ans);

//map-filter-reduce


// const arr1=[10,22,34];
// const ans1=arr1.map((a)=>{
//     console.log(a);
//     return a*2;
// });

// console.log(ans1);

// const arr2=[10,22,34];
// const ans2=arr2.map((a)=>a**2)

// console.log(ans2);

//filter

// const arr=[10,22,34];
// arr.push(88);
// console.log(arr);

// const arr=[10,22,34];
// const ans=arr.filter((a)=>{
//     if(a>20) return true;
//     else return false;
// });

// console.log(arr);
// console.log(ans);
   

// const arr=[
//     'delhi','mumbai','chennai','dubai','canada'
// ]
// const ans=arr.filter((a)=>{
//     if(a.includes('i')||a.includes('I'))
//     {
//         return true;
//     }
//     else false;
// });

// console.log(ans);
//include function
// let text = "Hello world, welcome to the universe.";
// let result = text.includes("world");
// console.log(result);

// const arr=['delhi,India','mumbai,india','chennai,India','dubai,jsdhsd','canada,shcvdg','texas,USA']
  
// const ans=arr.filter((a)=>{
//     const ns=a.toLowerCase();
//     if(ns.includes('india'))
//     {
//         return true;
//     }
//     else false;
// });
// console.log(ans);

//reduce in javascript

// const arr = [10,22,34];

// const ans = arr.reduce((a,b,c)=>{
//     console.log(a,b,c);
//     return  a+b;
// })

// console.log(ans);


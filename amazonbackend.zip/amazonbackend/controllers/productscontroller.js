const productModel= require('../models/productsmodel.js');
const getAllproducts=async(req,res)=>{
    const data=await productModel.find();
    // console.log(data);
    res.json({
        status:'success',
        results:0,
        data:{
            products:data,
        }
    })
}
 const addProduct=async(req,res)=>{
    try{
    const {_id,...data}=req.body;
    const res=await productModel.create(reqData);
    console.log(req.body);
    res.json({
        status:'success',
        results:1,
        data:{
            products:data,
        }
    })
}
   catch(err){
    res.status(403);
    console.log(err);
    res.json({
        status:'failed',
        results:1,
        message:JSON.stringify(err),
    })
}
 }
 const replaceProduct=async(req,res)=>{
    try{
    const reqId=req.params.id;
    const data={...req.body,reqId};
    const result=await productModel.findOneAndReplace({_id:reqId},data);
    res.json({
        status:'success',
        data:{
            products:result,
        }
    })
 }
 catch(err){
    res.status(500);
    // console.log(err);
    res.json({
        status:'success',
        message:JSON.stringify(err),
    })
}
}
const deleteProduct=async(req,res)=>{
        try{
            const reqId=req.params.id;
            const data={...req.body,reqId};
            const result=await productModel.deleteOne({_id:reqId},data);
            res.json({
                status:'success',
                data:{
                    products:result,
                }
            })
         }
         catch(err){
            res.status(500);
            // console.log(err);
            res.json({
                status:'success',
                message:JSON.stringify(err),
            })
        }
    }
    // const findbyProduct=async(req,res)=>{
    //     try{
    //         const reqId=req.params.id;
    //         const data={...req.body,reqId};
    //         const result=await productModel.findByIdAndDelete({_id:reqId},data);
    //         res.json({
    //             status:'success',
    //             data:{
    //                 products:result,
    //             }
    //         })
    //      }
    //      catch(err){
    //         res.status(500);
    //         // console.log(err);
    //         res.json({
    //             status:'success',
    //             message:JSON.stringify(err),
    //         })
    //     } 
    // }

module.exports ={
     getAllproducts,
     addProduct,
     replaceProduct,
     deleteProduct,
    //  findbyProduct,
    }

//reduce operator

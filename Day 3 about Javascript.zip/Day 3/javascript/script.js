// console.group('hello');
// function env()
// {
//     // console.log(message);
//     for( var i=0;i<5;i++)
//     {
//         console.log(i);
//     }
// }
// env();
// var message = 'hello';
// console.log(message)
// message = "else";
// console.log(message);

//looselytape


//let
// let message="hello";
// let charactermessage="else";
// console.log(message);
// console.log(charactermessage);

// const message = "hello";
// console.log(message);

// let age='abcd';
// age='abcd';
// console.log(typeof(age))

//java script data types
//string
//number
//bigingt

// let useAge = 'abcd';
// userAge = 'abbd'

// let arr = ['a','r','r','a','y'];
// arr[0] = 'abcd';
// console.log(arr)
// parseint
// let str='12';
// let age=20;
// let ans=age + parseInt(str);
// console.log(ans);

// const str= 'khan';
// const usrname = 'My Name Is: ';  //try
// const ans = `${usrname} ${str}`
// console.log(ans);   

// function print(str='nothing is here'){
//     console.log(str);
// }

// print( );
// about arow function
//return of values from arrow function


//object

// const obj = new Object();
// obj['firstname']='one';
// obj['secondname']='dsnjvshaksj';
// obj[45]='alnvj';
// console.log(obj);
  
// const obj = {
//     'firstname':'kdsbh',
//     'secondname':'dnfjd',
//     'age':98,
//     'address':'fndj',           
// };
//how to print name in object means how to give space between them

//const firstname = obj.firstname + ' ' + obj.lastname;

// const x=prompt('Please tell me dsjhvs');

// console.log(obj[x]);
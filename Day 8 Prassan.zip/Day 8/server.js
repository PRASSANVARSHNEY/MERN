const express = require('express');

const app = express()

app.get('/products',(req,res)=>{
    res.send("HOME PAGE");
})
 

app.post('/products',(req,res)=>{
    res.send("HOME PAGE");
})


app.patch('/products',(req,res)=>{
    res.send("HOME PAGE");
})


app.get('/home',(req,res)=>{
    res.send("HOME PAGE");
})


app.get('/home',(req,res)=>{
    res.send("HOME PAGE");
})

app.listen(1600);